import os
os.system("python geonames_angola.py")
os.system("python osm_roads_angola.py")
os.system("python worldclim_angola.py")
print("Todos os downloads concluídos!")